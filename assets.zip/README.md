# sinako
Repository with auto-unzip workflow
