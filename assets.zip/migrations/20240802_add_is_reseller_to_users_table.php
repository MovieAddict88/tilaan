<?php
$sql = 'ALTER TABLE users ADD COLUMN is_reseller BOOLEAN NOT NULL DEFAULT 0';
?>