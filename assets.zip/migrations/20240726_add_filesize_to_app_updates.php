<?php
// This column is already created in install.php.
// We use a no-op statement to ensure the migration is marked as run without causing an error.
$sql = 'DO 1;';
?>