<?php
$sql = 'ALTER TABLE resellers ADD COLUMN commission_rate DECIMAL(5, 2) NOT NULL DEFAULT 0.10';
?>
