<?php
// Start session
session_start();

// Check if the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: login.php');
    exit;
}

// Include the database connection file
require_once 'db_config.php';

// Fetch VPN sessions from the database
$sql = 'SELECT vpn_sessions.id, users.username, vpn_sessions.start_time, vpn_sessions.end_time, vpn_sessions.ip_address
        FROM vpn_sessions
        JOIN users ON vpn_sessions.user_id = users.id';
$sessions = $pdo->query($sql);

include 'header.php';
?>

<div class="page-header">
    <h1>VPN Monitoring</h1>
</div>

<div class="card">
    <div class="card-header">
        <h3>VPN Usage Statistics</h3>
    </div>
    <div class="card-body">
        <div class="chart-container">
            <canvas id="vpnUsageChart"></canvas>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>VPN Sessions</h3>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class='table'>
                <thead>
                    <tr>
                        <th>Session ID</th>
                        <th>Username</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $userSessions = []; // Initialize for chart data
                    foreach ($sessions as $session) :
                        // Prepare data for the chart
                        $username = htmlspecialchars($session['username']);
                        if (!isset($userSessions[$username])) {
                            $userSessions[$username] = 0;
                        }
                        $userSessions[$username]++;
                    ?>
                        <tr>
                            <td data-label='Session ID'><?php echo $session['id']; ?></td>
                            <td data-label='Username'><?php echo $username; ?></td>
                            <td data-label='Start Time'><?php echo $session['start_time']; ?></td>
                            <td data-label='End Time'><?php echo $session['end_time']; ?></td>
                            <td data-label='IP Address'><?php echo htmlspecialchars($session['ip_address']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const sessionsData = <?php echo json_encode($userSessions); ?>;

    const ctx = document.getElementById('vpnUsageChart').getContext('2d');
    const vpnUsageChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(sessionsData),
            datasets: [{
                label: '# of Sessions',
                data: Object.values(sessionsData),
                backgroundColor: 'rgba(67, 97, 238, 0.7)',
                borderColor: 'rgba(67, 97, 238, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
</script>

<?php include 'footer.php'; ?>