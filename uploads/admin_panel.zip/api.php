<?php
// Include the database connection file
require_once 'db_config.php';

// Check if the login_code and device_id are set
if (isset($_GET['login_code']) && isset($_GET['device_id'])) {
    $login_code = $_GET['login_code'];
    $device_id = $_GET['device_id'];

    // Check if the user exists and the device ID is empty
    $sql = 'SELECT * FROM users WHERE login_code = :login_code AND (device_id = :device_id OR device_id IS NULL)';

    if ($stmt = $pdo->prepare($sql)) {
        $stmt->bindParam(':login_code', $login_code, PDO::PARAM_STR);
        $stmt->bindParam(':device_id', $device_id, PDO::PARAM_STR);

        if ($stmt->execute()) {
            if ($stmt->rowCount() == 1) {
                $user = $stmt->fetch();
                if (empty($user['device_id'])) {
                    // Device ID is not set, so update it
                    $updateSql = 'UPDATE users SET device_id = :device_id WHERE login_code = :login_code';
                    if ($updateStmt = $pdo->prepare($updateSql)) {
                        $updateStmt->bindParam(':device_id', $device_id, PDO::PARAM_STR);
                        $updateStmt->bindParam(':login_code', $login_code, PDO::PARAM_STR);
                        $updateStmt->execute();
                    }
                }

                // Log the VPN session
                $insertSessionSql = 'INSERT INTO vpn_sessions (user_id, start_time, ip_address) VALUES (:user_id, NOW(), :ip_address)';
                if ($insertStmt = $pdo->prepare($insertSessionSql)) {
                    $insertStmt->bindParam(':user_id', $user['id'], PDO::PARAM_INT);
                    $insertStmt->bindParam(':ip_address', $_SERVER['REMOTE_ADDR'], PDO::PARAM_STR);
                    $insertStmt->execute();
                }

                echo 'success';
            } else {
                echo 'failure';
            }
        } else {
            echo 'failure';
        }
    }
} else {
    echo 'failure';
}
