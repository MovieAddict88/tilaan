<?php
// Include the database configuration file
require_once 'db_config.php';

try {
    // Create the users table
    $sql_users = 'CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        login_code VARCHAR(255) NOT NULL UNIQUE,
        device_id VARCHAR(255)
    )';
    $pdo->exec($sql_users);

    $sql_vpn_sessions = 'CREATE TABLE IF NOT EXISTS vpn_sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        start_time DATETIME NOT NULL,
        end_time DATETIME,
        ip_address VARCHAR(255) NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )';
    $pdo->exec($sql_vpn_sessions);

    // Check if the admin user already exists
    $stmt = $pdo->prepare('SELECT id FROM users WHERE username = :username');
    $stmt->execute(['username' => 'admin']);
    if ($stmt->rowCount() === 0) {
        // Admin user does not exist, so create it
        $admin_user = 'admin';
        $admin_pass = password_hash('password', PASSWORD_DEFAULT);
        $admin_login_code = 'ADMIN-001';

        $insert_admin_sql = 'INSERT INTO users (username, password, login_code) VALUES (:username, :password, :login_code)';
        $stmt = $pdo->prepare($insert_admin_sql);
        $stmt->execute([
            'username' => $admin_user,
            'password' => $admin_pass,
            'login_code' => $admin_login_code
        ]);
        echo 'Default admin user created successfully.<br>';
    }

    echo 'Database, tables, and default admin user are set up.';
} catch (PDOException $e) {
    die('ERROR: Could not execute sql statement. ' . $e->getMessage());
}
