<?php
// Include the database connection file
require_once 'db_config.php';

try {
    // SQL to create table
    $sql = "CREATE TABLE IF NOT EXISTS zip_password (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        password VARCHAR(255) NOT NULL
    )";

    // use exec() because no results are returned
    $pdo->exec($sql);
    echo "Table zip_password created successfully<br>";

    // SQL to insert password
    $sql = "INSERT INTO zip_password (password) VALUES ('cornerstone')";
    $pdo->exec($sql);
    echo "Password inserted successfully<br>";

} catch (PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
}
