<?php
// Get the current page name
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>VPN Admin Panel</title>
    <link rel='stylesheet' href='style.css'>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <button class="mobile-nav-toggle" id="mobileNavToggle">
        <span class="material-icons">menu</span>
    </button>
    
    <div class='sidebar' id="sidebar">
        <div class='sidebar-header'>
            <h2>VPN Panel</h2>
        </div>
        <ul>
            <li class='<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>'>
                <a href='index.php'>
                    <span class="material-icons">people</span>
                    User Management
                </a>
            </li>
            <li class='<?php echo ($current_page == 'monitoring.php') ? 'active' : ''; ?>'>
                <a href='monitoring.php'>
                    <span class="material-icons">monitoring</span>
                    VPN Monitoring
                </a>
            </li>
            <li>
                <a href='logout.php'>
                    <span class="material-icons">logout</span>
                    Logout
                </a>
            </li>
        </ul>
    </div>
    <div class='content'>
        <div class='container'>