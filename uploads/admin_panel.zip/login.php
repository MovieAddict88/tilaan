<?php
// Start session
session_start();

// Check if the user is already logged in, if yes then redirect to the welcome page
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('location: index.php');
    exit;
}

// Include the database connection file
require_once 'db_config.php';

// Define variables and initialize with empty values
$username = $password = '';
$username_err = $password_err = '';

// Processing form data when form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if username is empty
    if (empty(trim($_POST['username']))) {
        $username_err = 'Please enter username.';
    } else {
        $username = trim($_POST['username']);
    }

    // Check if password is empty
    if (empty(trim($_POST['password']))) {
        $password_err = 'Please enter your password.';
    } else {
        $password = trim($_POST['password']);
    }

    // Validate credentials
    if (empty($username_err) && empty($password_err)) {
        // Prepare a select statement
        $sql = 'SELECT id, username, password FROM users WHERE username = :username';

        if ($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':username', $param_username, PDO::PARAM_STR);

            // Set parameters
            $param_username = $username;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Check if username exists, if yes then verify password
                if ($stmt->rowCount() == 1) {
                    if ($row = $stmt->fetch()) {
                        $id = $row['id'];
                        $hashed_password = $row['password'];
                        if (password_verify($password, $hashed_password)) {
                            // Password is correct, so start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION['loggedin'] = true;
                            $_SESSION['id'] = $id;
                            $_SESSION['username'] = $username;

                            // Redirect user to welcome page
                            header('location: index.php');
                        } else {
                            // Display an error message if password is not valid
                            $password_err = 'The password you entered was not valid.';
                        }
                    }
                } else {
                    // Display an error message if username doesn't exist
                    $username_err = 'No account found with that username.';
                }
            } else {
                echo 'Oops! Something went wrong. Please try again later.';
            }

            // Close statement
            unset($stmt);
        }
    }

    // Close connection
    unset($pdo);
}
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Login - VPN Admin Panel</title>
    <link rel='stylesheet' href='style.css'>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="login-page">
    <div class='login-container'>
        <div style="text-align: center; margin-bottom: 30px;">
            <span class="material-icons" style="font-size: 3rem; color: #4361ee; margin-bottom: 10px;">vpn_lock</span>
            <h2 style="color: #4361ee;">VPN Admin Panel</h2>
        </div>
        <p style="text-align: center; margin-bottom: 30px; color: #6c757d;">Please fill in your credentials to login.</p>
        <form action='login.php' method='post'>
            <div class='form-group'>
                <label class="form-label">Username</label>
                <input type='text' name='username' class='form-control' value='<?php echo htmlspecialchars($username); ?>'>
                <span class='text-danger'><?php echo $username_err; ?></span>
            </div>
            <div class='form-group'>
                <label class="form-label">Password</label>
                <input type='password' name='password' class='form-control'>
                <span class='text-danger'><?php echo $password_err; ?></span>
            </div>
            <div class='form-group'>
                <input type='submit' class='btn btn-primary' value='Login' style='width: 100%; padding: 14px;'>
            </div>
        </form>
    </div>
</body>
</html>