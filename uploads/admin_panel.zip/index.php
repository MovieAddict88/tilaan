<?php
// Start session
session_start();

// Check if the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: login.php');
    exit;
}

// Include the database connection file
require_once 'db_config.php';

// Fetch users from the database
$sql = 'SELECT id, username, login_code, device_id FROM users';
$users = $pdo->query($sql);

include 'header.php';
?>

<div class="page-header">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
    <div class="page-actions">
        <a href='add_user.php' class='btn btn-success'>
            <span class="material-icons">person_add</span>
            Add New User
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>User Management</h3>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class='table'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Login Code</th>
                        <th>Device ID</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user) : ?>
                        <tr>
                            <td data-label='ID'><?php echo $user['id']; ?></td>
                            <td data-label='Username'><?php echo htmlspecialchars($user['username']); ?></td>
                            <td data-label='Login Code'><?php echo htmlspecialchars($user['login_code']); ?></td>
                            <td data-label='Device ID'><?php echo htmlspecialchars($user['device_id']); ?></td>
                            <td data-label='Actions'>
                                <div class="action-buttons">
                                    <a href='edit_user.php?id=<?php echo $user['id']; ?>' class='btn btn-primary btn-sm'>
                                        <span class="material-icons">edit</span>
                                        Edit
                                    </a>
                                    <a href='delete_user.php?id=<?php echo $user['id']; ?>' class='btn btn-danger btn-sm'>
                                        <span class="material-icons">delete</span>
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>