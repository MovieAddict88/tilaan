<?php
// Include the database connection file
require_once 'db_config.php';

// SQL to get the password
$sql = "SELECT password FROM zip_password ORDER BY id DESC LIMIT 1";

if ($stmt = $pdo->prepare($sql)) {
    if ($stmt->execute()) {
        if ($stmt->rowCount() == 1) {
            $row = $stmt->fetch();
            echo $row['password'];
        } else {
            echo "failure";
        }
    } else {
        echo "failure";
    }
}
?>