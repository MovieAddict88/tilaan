<?php
// Process delete operation after confirmation
if (isset($_POST['id']) && !empty($_POST['id'])) {
    // Include the database connection file
    require_once 'db_config.php';

    // Prepare a delete statement
    $sql = 'DELETE FROM users WHERE id = :id';

    if ($stmt = $pdo->prepare($sql)) {
        // Bind variables to the prepared statement as parameters
        $stmt->bindParam(':id', $param_id, PDO::PARAM_INT);

        // Set parameters
        $param_id = trim($_POST['id']);

        // Attempt to execute the prepared statement
        if ($stmt->execute()) {
            // Records deleted successfully. Redirect to landing page
            header('location: index.php');
            exit();
        } else {
            echo 'Oops! Something went wrong. Please try again later.';
        }
    }

    // Close statement
    unset($stmt);

    // Close connection
    unset($pdo);
} else {
    // Check existence of id parameter
    if (empty(trim($_GET['id']))) {
        // URL doesn't contain id parameter. Redirect to error page
        header('location: error.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Delete User</title>
    <link rel='stylesheet' href='style.css'>
    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class='container'>
        <div class="page-header">
            <h2>Delete User</h2>
            <div class="page-actions">
                <a class='btn btn-secondary' href='index.php'>
                    <span class="material-icons">arrow_back</span>
                    Back to Users
                </a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-body">
                <form action='delete_user.php' method='post'>
                    <div class='alert alert-danger'>
                        <input type='hidden' name='id' value='<?php echo trim($_GET['id']); ?>'/>
                        <p>Are you sure you want to delete this user?</p>
                        <div class="form-group" style="margin-top: 20px;">
                            <input type='submit' value='Yes, Delete User' class='btn btn-danger'>
                            <a class='btn btn-link' href='index.php'>Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>