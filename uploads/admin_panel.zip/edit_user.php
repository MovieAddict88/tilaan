<?php
// Include the database connection file
require_once 'db_config.php';

// Define variables and initialize with empty values
$username = $login_code = $device_id = '';
$username_err = $login_code_err = $device_id_err = '';

// Processing form data when form is submitted
if (isset($_POST['id']) && !empty($_POST['id'])) {
    $id = $_POST['id'];

    // Validate username
    if (empty(trim($_POST['username']))) {
        $username_err = 'Please enter a username.';
    } else {
        $username = trim($_POST['username']);
    }

    // Validate login code
    if (empty(trim($_POST['login_code']))) {
        $login_code_err = 'Please enter a login code.';
    } else {
        $login_code = trim($_POST['login_code']);
    }

    // Validate device ID
    if (empty(trim($_POST['device_id']))) {
        $device_id_err = 'Please enter a device ID.';
    } else {
        $device_id = trim($_POST['device_id']);
    }

    // Check input errors before updating in database
    if (empty($username_err) && empty($login_code_err) && empty($device_id_err)) {
        // Prepare an update statement
        $sql = 'UPDATE users SET username = :username, login_code = :login_code, device_id = :device_id WHERE id = :id';

        if ($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':username', $param_username, PDO::PARAM_STR);
            $stmt->bindParam(':login_code', $param_login_code, PDO::PARAM_STR);
            $stmt->bindParam(':device_id', $param_device_id, PDO::PARAM_STR);
            $stmt->bindParam(':id', $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_username = $username;
            $param_login_code = $login_code;
            $param_device_id = $device_id;
            $param_id = $id;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Records updated successfully. Redirect to landing page
                header('location: index.php');
                exit();
            } else {
                echo 'Something went wrong. Please try again later.';
            }

            // Close statement
            unset($stmt);
        }
    }

    // Close connection
    unset($pdo);
} else {
    // Check existence of id parameter before processing further
    if (isset($_GET['id']) && !empty(trim($_GET['id']))) {
        // Get URL parameter
        $id =  trim($_GET['id']);

        // Prepare a select statement
        $sql = 'SELECT * FROM users WHERE id = :id';
        if ($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':id', $param_id, PDO::PARAM_INT);

            // Set parameters
            $param_id = $id;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);

                    // Retrieve individual field value
                    $username = $row['username'];
                    $login_code = $row['login_code'];
                    $device_id = $row['device_id'];
                } else {
                    // URL doesn't contain valid id. Redirect to error page
                    header('location: error.php');
                    exit();
                }
            } else {
                echo 'Oops! Something went wrong. Please try again later.';
            }

            // Close statement
            unset($stmt);
        }

        // Close connection
        unset($pdo);
    } else {
        // URL doesn't contain id parameter. Redirect to error page
        header('location: error.php');
        exit();
    }
}

include 'header.php';
?>

<div class="page-header">
    <h2>Edit User</h2>
    <div class="page-actions">
        <a class='btn btn-secondary' href='index.php'>
            <span class="material-icons">arrow_back</span>
            Back to Users
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>Update User Information</h3>
    </div>
    <div class="card-body">
        <div class="form-container">
            <p>Please edit the input values and submit to update the user record.</p>
            <form action='edit_user.php' method='post'>
                <div class='form-group'>
                    <label class="form-label">Username</label>
                    <input type='text' name='username' class='form-control' value='<?php echo htmlspecialchars($username); ?>'>
                    <span class='text-danger'><?php echo $username_err; ?></span>
                </div>
                <div class='form-group'>
                    <label class="form-label">Login Code</label>
                    <input type='text' name='login_code' class='form-control' value='<?php echo htmlspecialchars($login_code); ?>'>
                    <span class='text-danger'><?php echo $login_code_err; ?></span>
                </div>
                <div class='form-group'>
                    <label class="form-label">Device ID</label>
                    <input type='text' name='device_id' class='form-control' value='<?php echo htmlspecialchars($device_id); ?>'>
                    <span class='text-danger'><?php echo $device_id_err; ?></span>
                </div>
                <input type='hidden' name='id' value='<?php echo $id; ?>'/>
                <div class='form-group'>
                    <input type='submit' class='btn btn-primary' value='Update User'>
                    <a class='btn btn-link' href='index.php'>Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>