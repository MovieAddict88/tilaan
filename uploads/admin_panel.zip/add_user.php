<?php
// Include the database connection file
require_once 'db_config.php';

// Define variables and initialize with empty values
$username = $password = $login_code = '';
$username_err = $password_err = $login_code_err = '';

// Processing form data when form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate username
    if (empty(trim($_POST['username']))) {
        $username_err = 'Please enter a username.';
    } else {
        // Prepare a select statement
        $sql = 'SELECT id FROM users WHERE username = :username';

        if ($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':username', $param_username, PDO::PARAM_STR);

            // Set parameters
            $param_username = trim($_POST['username']);

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                if ($stmt->rowCount() == 1) {
                    $username_err = 'This username is already taken.';
                } else {
                    $username = trim($_POST['username']);
                }
            } else {
                echo 'Oops! Something went wrong. Please try again later.';
            }

            // Close statement
            unset($stmt);
        }
    }

    // Validate password
    if (empty(trim($_POST['password']))) {
        $password_err = 'Please enter a password.';
    } elseif (strlen(trim($_POST['password'])) < 6) {
        $password_err = 'Password must have atleast 6 characters.';
    } else {
        $password = trim($_POST['password']);
    }

    // Validate login code
    if (empty(trim($_POST['login_code']))) {
        $login_code_err = 'Please enter a login code.';
    } else {
        $login_code = trim($_POST['login_code']);
    }

    // Check input errors before inserting in database
    if (empty($username_err) && empty($password_err) && empty($login_code_err)) {
        // Prepare an insert statement
        $sql = 'INSERT INTO users (username, password, login_code) VALUES (:username, :password, :login_code)';

        if ($stmt = $pdo->prepare($sql)) {
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':username', $param_username, PDO::PARAM_STR);
            $stmt->bindParam(':password', $param_password, PDO::PARAM_STR);
            $stmt->bindParam(':login_code', $param_login_code, PDO::PARAM_STR);

            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $param_login_code = $login_code;

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Redirect to login page
                header('location: index.php');
            } else {
                echo 'Something went wrong. Please try again later.';
            }

            // Close statement
            unset($stmt);
        }
    }

    // Close connection
    unset($pdo);
}

include 'header.php';
?>

<div class="page-header">
    <h2>Add New User</h2>
    <div class="page-actions">
        <a class='btn btn-secondary' href='index.php'>
            <span class="material-icons">arrow_back</span>
            Back to Users
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h3>User Information</h3>
    </div>
    <div class="card-body">
        <div class="form-container">
            <p>Please fill this form to create a new user.</p>
            <form action='add_user.php' method='post'>
                <div class='form-group'>
                    <label class="form-label">Username</label>
                    <input type='text' name='username' class='form-control' value='<?php echo htmlspecialchars($username); ?>'>
                    <span class='text-danger'><?php echo $username_err; ?></span>
                </div>
                <div class='form-group'>
                    <label class="form-label">Password</label>
                    <input type='password' name='password' class='form-control'>
                    <span class='text-danger'><?php echo $password_err; ?></span>
                </div>
                <div class='form-group'>
                    <label class="form-label">Login Code</label>
                    <input type='text' name='login_code' class='form-control' value='<?php echo htmlspecialchars($login_code); ?>'>
                    <span class='text-danger'><?php echo $login_code_err; ?></span>
                </div>
                <div class='form-group'>
                    <input type='submit' class='btn btn-primary' value='Create User'>
                    <a class='btn btn-link' href='index.php'>Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>